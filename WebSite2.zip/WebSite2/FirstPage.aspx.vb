﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub postFB_click(ByVal sender As System.Object,
    ByVal e As System.EventArgs) Handles postFB.Click
        'Server.Transfer("FbLoginPage.aspx", True)
        Response.Redirect("FbLoginPage.aspx")
    End Sub

    Protected Sub postTwitter_click(ByVal sender As System.Object,
    ByVal e As System.EventArgs) Handles postTwitter.Click
        'Server.Transfer("TwitterLoginPage.aspx", True)
        Response.Redirect("TwitterLoginPage.aspx")
    End Sub

End Class
