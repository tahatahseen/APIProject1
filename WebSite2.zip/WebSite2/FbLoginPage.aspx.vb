﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub BtnCancel_Click(ByVal sender As System.Object,
   ByVal e As System.EventArgs) Handles BtnCancel.Click
        Response.Redirect("FirstPage.aspx")
    End Sub

End Class
