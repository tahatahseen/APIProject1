﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    'Protected Sub Login2_Authenticate(sender As Object, e As AuthenticateEventArgs) Handles Login2.Authenticate

    'End Sub

    Protected Sub BtnCancel1_Click(ByVal sender As System.Object,
   ByVal e As System.EventArgs) Handles BtnCancel1.Click

        Server.Transfer("FirstPage.aspx", True)
        ' Response.Redirect("FirstPage.aspx")
    End Sub

End Class
